#include <stdio.h>
// get elements of the list
void get_array(int array[100], int size)
{
    int i;
    printf("Enter %d items, you can have them seperated with a space bar: ", size);
    for(i=0; i<size; i++)
    {
        scanf("%d",&array[i]);
    }
}
// printing the list
void print_array(int array[100], int size)
{
    int i;
    printf("\nInput: ");
    for(i=0; i<size; i++)
    {
        printf("%d ",array[i]);
    }
}
// print array items without spacing
void print_as_string(int array[100], int size)
{
    int i;
    printf("\n\n");
    printf("Outpt: ");
    for(i=0; i<size; i++)
    {
        printf("%d",array[i]);
    }
}
/*sort out items of the array in descending order
void sort_array(int array[100], int size)
{
    int temp,i,j;
    for(i=0; i<size-1; i++)
    {
        for(j=i+1; j<size; j++)
        {
            if(array[j]>array[i])
            {
                temp = array[j];
                array[j] = array[i];
                array[i] = temp;
            }
        }
    }
}*/
// this block uses array array to assign elements to array div_10
// compute successive divisions by 10 to get the first digit of every number in the array
// this is done so the first digits of the array can be compared easily
// to determine which number will give the final output a higher value
// this would work by collecting elements at index i in the array array
// perform successive divisions by 10 on this element till the element itself is less than 10
// store the final result from division in the array div_10
void get_first_digit(int array[100], int div_10[100], int size)
{
    int num, i;
    for(i=0; i<size; i++)
    {
        num = array[i];
        while(num>=10)
        {
            num= num/10;
        }
        div_10[i] = num;
    }
}
// this compares sorts elements in one array by comparring elements in another
// this block uses the array div_10 to sort array array
// each element in the array div_10 is the first digit of its corresponding index in array array
// compare elements in array div_10 to sort out elements of array array in descending order.
void compare_sort(int array[100], int div_10[100], int size)
{
    int temp,i,j;
    for(i=0; i<size-1; i++)
    {
        for(j=i+1; j<size; j++)
        {   // the first if is to verify that if the first digit of element at
            // index j is greater than that at index i, have their corresponding
            // elements in the array array swapped
            if(div_10[j]>div_10[i])
            {
                temp = array[j];
                array[j] = array[i];
                array[i] = temp;
            }
            // this other block verifies that in case there is one or more
            // occurences of elements having thesame first digit
            else if(div_10[i]==div_10[j])
            {
                // do a comparson for original elements in the array array
                // if two elements in the original array have thesame first digit, simply arrange them in descending order
                if(array[j]>array[i])
                {
                   temp = array[j];
                    array[j] = array[i];
                    array[i] = temp;
                }
            }
        }
    }
}
int main()
{
    int numbers[100], div_10[100], size;
    printf("Enter the number of items: ");
    scanf("%d", &size);
    printf("\n");
    get_array(numbers, size);
    print_array(numbers, size);
    get_first_digit(numbers, div_10, size);
    compare_sort(numbers, div_10, size);
    print_as_string(numbers, size);
    printf("\n\n");
    return 0;
}
